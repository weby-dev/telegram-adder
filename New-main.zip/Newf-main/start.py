import os
import time

os.system("python3 scrape.py")
time.sleep(40)
os.system("python3 getviews.py")
